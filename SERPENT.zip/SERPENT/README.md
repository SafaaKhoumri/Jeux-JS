# Vanilla JS Snake

A Pen created on CodePen.io. Original URL: [https://codepen.io/Saad-Eddine-SENNOUF/pen/xxvEEOw](https://codepen.io/Saad-Eddine-SENNOUF/pen/xxvEEOw).

This is a snake game I made with Vanilla Javascript.